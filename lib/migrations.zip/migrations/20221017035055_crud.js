exports.up = async (knex, Promise) => {
    
};

exports.down = async (knex, Promise) => {};
