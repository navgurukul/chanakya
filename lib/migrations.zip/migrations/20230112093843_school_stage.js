exports.up = async (knex) => {
    await knex.schema.createTable('main.school_stage', (table)=>{
        table.increments('id').primary();
        table.integer('school_id').references('id').inTable('main.school');
        table.string('name');
        table.string('stageType');
        table.string('description');
    })
};
exports.down = async (knex) => {
    await knex.schema.dropTable('school_stage');
};
